A3 INTERIOR DESIGN — WEBSITE

Files:
- index.html — main website
- style.css — premium black/gold responsive design
- script.js — mobile menu + current year
- assets/a3-logo.jpeg — supplied A3 logo

IMPORTANT:
The Projects section currently uses high-quality interior image URLs as visual placeholders.
Replace those image URLs in index.html with A3's own completed-project photographs for a genuine portfolio.

WhatsApp:
+91 73066 34314

Location:
Near Police Station, opposite KSEB Road,
Kambalakkad, Wayanad, Kerala

How to use:
1. Open index.html in a browser.
2. Upload the complete folder to your hosting provider.
3. Replace the project image URLs with your actual photos.
